
let dt = new Date() 
document.getElementById("txt").innerHTML= dt
